import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import java.util.Random;
import javafx.scene.image.Image;

public class Controller {

    @FXML
    private ImageView ImageSet;
    int number = 0;
    Random random = new Random();

    @FXML
    private Label NumberRolled;

    @FXML
    void RollDice(ActionEvent event) {
        number = random.nextInt(6)+1;
        NumberRolled.setText(String.valueOf(number));
        switch(number){
            case 1:
            ImageSet.setImage(new Image("cara1.png"));
            break;
            case 2:
            ImageSet.setImage(new Image("cara2.png"));
            break;
            case 3:
            ImageSet.setImage(new Image("cara3.png"));
            break;
            case 4:
            ImageSet.setImage(new Image("cara4.png"));
            break;
            case 5:
            ImageSet.setImage(new Image("cara5.png"));
            break;
            case 6:
            ImageSet.setImage(new Image("cara6.png"));
            break;

        }

    }

}
