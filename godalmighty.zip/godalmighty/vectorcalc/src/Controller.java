import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class Controller {
    @FXML
    private TextField xInput;

    @FXML
    private TextField yInput;

    @FXML
    private TextField magnitudeInput;

    @FXML
    private TextField directionInput;

    @FXML
    public void calculateVector() {
        if (!xInput.getText().isEmpty() && !yInput.getText().isEmpty()) {
            double x = Double.parseDouble(xInput.getText());
            double y = Double.parseDouble(yInput.getText());
            double magnitude = Math.sqrt(x * x + y * y);
            double direction = Math.toDegrees(Math.atan2(y, x));
            magnitudeInput.setText(String.format("%.2f", magnitude));
            directionInput.setText(String.format("%.2f", direction));
        } else if (!magnitudeInput.getText().isEmpty() && !directionInput.getText().isEmpty()) {
            double magnitude = Double.parseDouble(magnitudeInput.getText());
            double direction = Math.toRadians(Double.parseDouble(directionInput.getText()));
            double x = magnitude * Math.cos(direction);
            double y = magnitude * Math.sin(direction);
            xInput.setText(String.format("%.2f", x));
            yInput.setText(String.format("%.2f", y));
        }
    }
}
