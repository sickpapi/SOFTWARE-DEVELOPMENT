import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class Controller {

    @FXML
    private Label NumberDisplay;
    private int number = 0; 

    @FXML
    void ClickMinus(ActionEvent event) {
        number--;
        updateNumberDisplay();
    }

    @FXML
    void ClickPlus(ActionEvent event) {
        number++; 
        updateNumberDisplay();
    }

    private void updateNumberDisplay() {
        NumberDisplay.setText(String.valueOf(number));
    }
}
