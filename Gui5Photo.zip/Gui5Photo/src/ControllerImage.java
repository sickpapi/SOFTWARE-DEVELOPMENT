import javafx.animation.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.util.*;
import java.util.Random;

public class ControllerImage{

    @FXML
    private ImageView Image;
    int number = 1;
    Random random = new Random();
    private Timeline timeline;


    @FXML 
    public void initialize() {
        
        timeline = new Timeline(new KeyFrame(Duration.seconds(3), event -> SwitchImage()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    @FXML 
    void SwitchImage(){
        switch(number){
            case 1: Image.setImage(new Image("Goofy1.jpg"));
            break;
            case 2: Image.setImage(new Image("Goofy2.jpg"));
            break;
            case 3: Image.setImage(new Image("Goofy3.jpg"));
            break;
            case 4: Image.setImage(new Image("Goofy4.jpg"));
            break;
            case 5: Image.setImage(new Image("Goofy5.jpg"));
            break;
        }
        if(number > 4){
            number = 1;
        }
        else{
            number++;
        }

    }

    @FXML
    void SkipImage(ActionEvent event) {
        timeline.stop();
        switch(number){
            case 1:
                Image.setImage(new Image("Goofy1.jpg"));
                break;
            case 2:
                Image.setImage(new Image("Goofy2.jpg"));
                break;
            case 3:
                Image.setImage(new Image("Goofy3.jpg"));
                break;
            case 4:
                Image.setImage(new Image("Goofy4.jpg"));
                break;
            case 5:
                Image.setImage(new Image("Goofy5.jpg"));
                break;
        }
        if(number > 4){
            number = 1;
        }
        else{
            number++;
        }
        timeline.play();
    }

}
